﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade7
{
    public partial class frmEx1 : Form
    {
        public frmEx1()
        {
            InitializeComponent();
        }
        private void btnEspaco_Click(object sender, EventArgs e)
        {
            string es;
            int i, quantidadeEspaco = 0;

            try
            {
                
                es = richTxtLetra.Text;

                char[] espaco = es.ToArray();

                for (i = 0; i <= es.Length - 1; i++)
                {
                    if (Char.IsWhiteSpace(espaco[i]))
                    {
                        quantidadeEspaco += 1;
                    }
                }

                MessageBox.Show("Quantidade de espaços em branco são: " + quantidadeEspaco);
            }
            catch (Exception)
            {
                MessageBox.Show("Informação digitadas incorretas!!!!");
            }
        }

        private void btnLetraR_Click(object sender, EventArgs e)
        {
            string r;
            int i = 0, quantidadeR = 0;

            try
            {
                r = richTxtLetra.Text;

                char[] letraR = r.ToArray();

                while (i < r.Length)
                {
                    if (Convert.ToString(letraR[i]) == "R" || Convert.ToString(letraR[i]) == "r")
                    {
                        quantidadeR += 1;
                    }
                    i++;
                }

                MessageBox.Show("Quantide de r são: " + quantidadeR);
            }
            catch (Exception)
            {
                MessageBox.Show("Informação digitadas incorretas!!!!");
            }
        }

        private void btnParesLetras_Click(object sender, EventArgs e)
        {
            string p;
            int i = 0, quantidadePares = 0;

            try
            {
                p = richTxtLetra.Text;

                char[] pares = p.ToArray();

                foreach (char pr in pares)
                {
                    if (i == 0)
                    {
                        i++;
                    }
                    else if (Char.Equals(i + 1, p.Length + 1))
                    {

                    }
                    else if (Char.Equals(pares[i - 1], pares[i]))
                    {
                        quantidadePares += 1;
                        i++;
                    }
                    else
                    {
                        i++;
                    }

                }

                MessageBox.Show("Quantide de pares são: " + quantidadePares);
            }
            catch (Exception)
            {
                MessageBox.Show("Informação digitadas incorretas!!!!");
            }
        }
    }
}
