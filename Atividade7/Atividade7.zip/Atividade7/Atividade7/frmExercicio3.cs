﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade7
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnPalindromo_Click(object sender, EventArgs e)
        {
            string reverso;
            reverso = "";
            try
            {
                string frase = txtFrase.Text;
                if (frase != "")
                {

                    if (frase.Length > 50)
                    {
                        MessageBox.Show("Quantidade de caracteres não permitido");
                    }
                    else
                    {
                        frase = frase.Replace(" ", "");
                        frase = frase.ToUpper();
                        char[] array = frase.ToCharArray();
                        Array.Reverse(array);

                        foreach (char c in array)
                        {
                            reverso = reverso + c.ToString();
                        }
                        if (frase == reverso)
                        {
                            MessageBox.Show("A frase: " + txtFrase.Text + " é um palíndromo");
                        }
                        else
                        {
                            MessageBox.Show("A frase: " + txtFrase.Text + " não  é um palíndromo");
                        }
                    }


                }
                else
                {
                    MessageBox.Show("Informação vazia!!!");
                }
            }
            catch(Exception)
            {

            }
           
            
                

           
        }
    }
}
