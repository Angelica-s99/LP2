﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade7
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double a, salarioBruto, gratificacao, b = 0.0, c = 0.0, d = 0.0;
            
            int producao;
            string nome, cargo, numeroInscricao;


            try
            {

                nome = txtNome.Text;
                cargo = txtCargo.Text;
                numeroInscricao = txtNumeroInscricao.Text;

                a = Convert.ToDouble(txtSalario.Text);
                producao = Convert.ToInt32(txtProducao.Text);
                gratificacao = Convert.ToDouble(txtGratificacao.Text);

                if (producao >= 100)
                {
                    b = 1.0;
                }
                else
                {
                    b = 0.0;
                }

                if (producao >= 120)
                {
                    c = 1.0;
                }
                else
                {
                    c = 0.0;
                }

                if (producao >= 150)
                {
                    d = 1.0;
                }
                else
                {
                    d = 0.0;
                }

                salarioBruto = a + (a * ((0.05 * b) + (0.1 * c) + (0.1 * d)));

                if (salarioBruto <= 7000)
                {
                    if (gratificacao > 0)
                    {
                        MessageBox.Show("Funcionário(a): " + nome +
                                   "\nCargo: " + cargo +
                                    "\nNúmero Inscrição: " + numeroInscricao +
                                    "\nProdução: " + producao +
                                    "\nSalário: " + a +
                                    "\nGratificação: " + gratificacao +
                                    "\nGanha de salário bruto de: " + salarioBruto);
                    }
                    else
                    {
                        MessageBox.Show("Funcionário(a): " + nome +
                                    "\nCargo: " + cargo +
                                    "\nNúmero Inscrição: " + numeroInscricao +
                                    "\nProdução: " + producao +
                                    "\nSalário: " + a +
                                    "\nGanha de salário bruto de: " + salarioBruto);
                    }

                }
                else if (salarioBruto > 7000 && producao >= 150 && gratificacao > 0)
                {
                    MessageBox.Show("Funcionário(a): " + nome +
                                    "\nCargo: " + cargo +
                                    "\nNúmero Inscrição: " + numeroInscricao +
                                    "\nProdução: " + producao +
                                    "\nSalário: " + a +
                                    "\nGratificação: " + gratificacao +
                                    "\nGanha de salário bruto de: " + salarioBruto);
                }
                else
                {
                    MessageBox.Show("Não atinge as especificações!!!!!");
                }
           }
            catch (Exception)
            {
                MessageBox.Show("Informações incorretas!!!!!");
            }
            
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtCargo.Text = "";
            txtGratificacao.Text = "";
            txtNome.Text = "";
            txtNumeroInscricao.Text = "";
            txtProducao.Text = "";
            txtSalario.Text = "";
        }
    }
}
