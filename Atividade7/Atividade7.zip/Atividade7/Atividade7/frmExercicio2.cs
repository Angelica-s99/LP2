﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade7
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnNumero_Click(object sender, EventArgs e)
        {
            try
            {


                double h = 0.0, fracao;
                int n = Convert.ToInt32(txtNumero.Text);

                if (!int.TryParse(txtNumero.Text, out n))
                {
                    MessageBox.Show("Não foi inserido número!!!!!!");
                }
                else if (n != 0)
                {
                    for (int i = 1; i <= n; i++)
                    {
                        fracao = (double)1 / i;
                        h = h + fracao;
                    }
                    MessageBox.Show("O resultado de h: " + h.ToString("N2"));
                }
                else
                {
                    MessageBox.Show("Não existe divisão por 0!!!!!!");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Informação inválida!!!");
            }
            
        }
    }
}
