﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade7
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void exercício1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmEx1 frmEx1 = new frmEx1();
            frmEx1.MdiParent = this;
            frmEx1.WindowState = FormWindowState.Maximized;
            frmEx1.Show();
           
        }

        private void exercício2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExercicio2 frmEx2 = new frmExercicio2();
            frmEx2.MdiParent = this;
            frmEx2.WindowState = FormWindowState.Maximized;
            frmEx2.Show();
        }

        private void exercício3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExercicio3 frmEx3 = new frmExercicio3();
            frmEx3.MdiParent = this;
            frmEx3.WindowState = FormWindowState.Maximized;
            frmEx3.Show();
        }

        private void exercício4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExercicio4 frmEx4 = new frmExercicio4();
            frmEx4.MdiParent = this;
            frmEx4.WindowState = FormWindowState.Maximized;
            frmEx4.Show();
        }
    }
}
