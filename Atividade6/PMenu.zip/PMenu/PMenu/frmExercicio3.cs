﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMenu
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnRemover2_Click(object sender, EventArgs e)
        {
            try
            {
                if(txtPalavra1.Text == "" || txtPalavra2.Text == "")
                {
                    MessageBox.Show("Informações não informadas corretamente!!!!");
                }
                else
                {
                    txtPalavra2.Text = txtPalavra2.Text.Replace(txtPalavra1.Text, "");
                }
                
            }
            catch(Exception)
            {
                MessageBox.Show("Informações não informadas corretamente!!!!");
            }

           
            
        }

        private void btnRemover1_Click(object sender, EventArgs e)
        {
            int posicao;

            try
            {
                if(txtPalavra1.Text == "" || txtPalavra2.Text == "")
                {
                    MessageBox.Show("Informações não informadas corretamente!!!!");
                }
                else 
                {
                    posicao = txtPalavra2.Text.IndexOf(txtPalavra1.Text);

                    while (posicao >= 0)
                    {
               
                        txtPalavra2.Text = txtPalavra2.Text.Substring(0, posicao) +
                        txtPalavra2.Text.Substring(posicao+txtPalavra1.Text.Length,
                        txtPalavra2.Text.Length-txtPalavra1.Text.Length-posicao);

                        posicao = txtPalavra2.Text.IndexOf(txtPalavra1.Text);
                    }
           
                }
                
            }
            catch(Exception)
            {
                MessageBox.Show("Informações não informadas corretamente!!!!");
            }

           
        }

        private void btnInverter_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtPalavra1.Text == "" || txtPalavra2.Text == "")
                {
                    MessageBox.Show("Informações não informadas corretamente!!!!");
                }
                else
                {
                    string s = txtPalavra1.Text;
                    char[] meuArray = s.ToCharArray();
                    Array.Reverse(meuArray);

                    foreach (char c in meuArray)
                    {
                        txtPalavra2.Text += c; 
                    }
                }
                
            }
            catch(Exception)
            {
                MessageBox.Show("Informações não informadas corretamente!!!!");
            }
           
        }
    }
}
