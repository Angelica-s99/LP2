﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMenu
{
    public partial class frmExercicio2 : Form
    {
        string palavra1, palavra2;
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnComparacao_Click(object sender, EventArgs e)
        {

            int comparar;

            try
            {
                palavra1 = txtPalavra1.Text;
                palavra2 = txtPalavra2.Text;

                comparar = Convert.ToInt32(String.Compare(palavra1, palavra2));

                if(comparar == 0)
                {
                    MessageBox.Show("São iguais");
                }
                else
                {
                    MessageBox.Show("Não são iguais");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Não inseriu os dados corretamente");
            }
           
        }

        private void btnInserir2_Click(object sender, EventArgs e)
        {
            string inserir, asterico = "**";

            int tamanhoPalavra1;

            palavra1 = txtPalavra1.Text;
            
            tamanhoPalavra1 = (palavra1.Length) / 2;
            inserir = palavra1.Insert(tamanhoPalavra1,asterico);

            txtPalavra2.Text = inserir;
        }

        private void btnInserir_Click(object sender, EventArgs e)
        {
            string inserir, primeiraPalavra2, segundaPalavra2;
            
            int metadePalavra2;
            
            palavra1 = txtPalavra1.Text;
            palavra2 = txtPalavra2.Text;

            
            metadePalavra2 = (palavra2.Length)/2;

            primeiraPalavra2 = palavra2.Substring(0, metadePalavra2);
            segundaPalavra2 = palavra2.Substring(metadePalavra2, palavra2.Length-metadePalavra2);

            inserir = primeiraPalavra2 + palavra1 + segundaPalavra2;

            MessageBox.Show(inserir);
        }
    }
}
