﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMenu
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            int numero1, numero2;

            try
            {
                numero1 = Convert.ToInt32(txtNumero1.Text);
                numero2 = Convert.ToInt32(txtNumero2.Text);

                if (!int.TryParse(txtNumero1.Text, out numero1) ||!int.TryParse(txtNumero2.Text, out numero2))
                {
                    MessageBox.Show("Não foi inserido informações de maneira correta!!!!!!!!!");
                }
                else
                {
                    Random rand = new Random();
                    MessageBox.Show(rand.Next(numero1, numero2).ToString());
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Erro!! Não foi inserido umas das informçãoes.");
            }
        }
    }
}
