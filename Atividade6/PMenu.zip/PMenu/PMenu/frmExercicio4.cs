﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMenu
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNumerico_Click(object sender, EventArgs e)
        {
            int i, totalNumeros=0;

            string c = richCaracter.Text;

            char[] caracter = c.ToCharArray();
           
            for (i = 0; i <= richCaracter.Text.Length-1; i++)
            {
                char stringona = Convert.ToChar(caracter[i]);


                if (Char.IsNumber(stringona))
                {
                    totalNumeros += 1;
                }

            }
            MessageBox.Show("Total de números digitados são: " + totalNumeros);
        
        }

        private void btnEspaco_Click(object sender, EventArgs e)
        {
            int j = 0;

            string espaco1 = richCaracter.Text;
            char[] espaco = espaco1.ToCharArray(); 

            while(j<= richCaracter.Text.Length-1)
            { 
                char stringona = Convert.ToChar(espaco[j]);
                
                if(Char.IsWhiteSpace(stringona))
                {
                    MessageBox.Show("A posição encontrada o espaço é: " +(j+1));

                    j = 1000;
                }
                else
                {
                    j++;
                }
            }
        }

        private void btnAlfabetico_Click(object sender, EventArgs e)
        {
            int totalAlfabetico = 0;

            int posicao = 0;
            string a = richCaracter.Text;

            char[] alfabetico = a.ToCharArray();

            foreach (Char c in alfabetico)
            {
               if (Char.IsLetter(alfabetico[posicao]))
                {
                    totalAlfabetico += 1;
                }
                posicao++;
      
            }
            MessageBox.Show("A quantidade de letras encontradas foi: " + totalAlfabetico);
        }
    }
}
