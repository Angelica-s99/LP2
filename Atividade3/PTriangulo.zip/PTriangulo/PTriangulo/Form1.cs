﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double ladoA, ladoB, ladoC;

            if(!double.TryParse(txtLadoA.Text, out ladoA) || !double.TryParse(txtLadoB.Text, out ladoB)
                || !double.TryParse(txtLadoC.Text, out ladoC))
            {
                MessageBox.Show("Não foi inserido valores");
            }
            else 
            {
                ladoA = Convert.ToDouble(txtLadoA.Text);
                ladoB = Convert.ToDouble(txtLadoB.Text);
                ladoC = Convert.ToDouble(txtLadoC.Text); 

                if((ladoA>Math.Abs(ladoB-ladoC)) && (ladoB>Math.Abs(ladoA-ladoC)) && (ladoC>Math.Abs(ladoA-ladoB))
                    && (ladoA<(ladoB+ladoC)) && (ladoB<(ladoA+ladoC)) && (ladoC<(ladoA+ladoB)))
                {
                    if(ladoA == ladoB && ladoA==ladoC)
                    { 
                        MessageBox.Show("Triângulo equilátero");
                        
                    }
                    else if (ladoA==ladoB || ladoA==ladoC || ladoB == ladoC)
                    {
                       MessageBox.Show("Triângulo isósceles");
                    }
                    else
                    {
                        MessageBox.Show("Triângulo escaleno");
                    }
                }
                else
                {
                    MessageBox.Show("As medidas mostram que não é triângulo");
                }
            }

            
        }
    }
}
