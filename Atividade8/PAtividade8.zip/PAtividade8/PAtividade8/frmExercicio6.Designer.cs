﻿namespace PAtividade8
{
    partial class frmExercicio6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMostrarMedia = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnMostrarMedia
            // 
            this.btnMostrarMedia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMostrarMedia.Location = new System.Drawing.Point(338, 199);
            this.btnMostrarMedia.Name = "btnMostrarMedia";
            this.btnMostrarMedia.Size = new System.Drawing.Size(156, 52);
            this.btnMostrarMedia.TabIndex = 0;
            this.btnMostrarMedia.Text = "Mostrar a média";
            this.btnMostrarMedia.UseVisualStyleBackColor = true;
            this.btnMostrarMedia.Click += new System.EventHandler(this.btnMostrarMedia_Click);
            // 
            // frmExercicio6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnMostrarMedia);
            this.Name = "frmExercicio6";
            this.Text = "frmExercicio6";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnMostrarMedia;
    }
}