﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade8
{
    public partial class frmExercicio6 : Form
    {
        public frmExercicio6()
        {
            InitializeComponent();
        }

        private void btnMostrarMedia_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            double[] media = new double[20];
            double soma=0;
            string resultado = "";
            string auxiliar = "";
            
            for(int i=0; i<20; i++)
            {
                for(int j=0; j < 3; j++)
                {

                    auxiliar = Interaction.InputBox("Digite a nota " + (j + 1) + " do aluno " + (i + 1),"Digite os dados");
                    if (!double.TryParse(auxiliar, out notas[i,j]))
                    {
                        MessageBox.Show("Valor inválido");
                        j--;
                    }

                }
            }
            for(int idx= 0; idx<20; idx++)
            {
                for (int idx2 = 0; idx2 < 3; idx2++)
                {
                    soma = soma + notas[idx, idx2]; 

                }
                   
                media[idx] = (double)soma / 3;
                soma = 0;
            }
            for (int a = 0; a < 20; a++)
            {
                resultado = resultado + "\n" + "Aluno " + (a + 1) + ": média: " + media[a].ToString("N2");
            }

            MessageBox.Show(resultado);
        }
    }
}
