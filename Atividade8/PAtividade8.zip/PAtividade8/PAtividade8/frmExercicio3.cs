﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade8
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {

            double[,] mercadoria = new double[2,10];
            double faturamento = 0;
            string auxiliar = "";

            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    if (j == 0)
                    {
                        auxiliar = Interaction.InputBox("Digite a quantidade do produto " + (i + 1), "Entrada de dados");
                        if (!double.TryParse(auxiliar, out mercadoria[j,i]))
                        {
                            MessageBox.Show("Valor inválido");
                            j--;
                        }
                    }
                    else
                    {
                        auxiliar = Interaction.InputBox("Digite o preço do produto " + (i + 1), "Entrada de dados");
                        if (!double.TryParse(auxiliar, out mercadoria[j, i]))
                        {
                            MessageBox.Show("Valor inválido");
                            j--;
                        }
                    }

                }
            }
            for (int f = 0; f < 10; f++)
            {
                faturamento = faturamento + mercadoria[0, f] * mercadoria[1, f];
            }

            MessageBox.Show("Faturamento mensal é de: " + faturamento);
        }
    }
}
