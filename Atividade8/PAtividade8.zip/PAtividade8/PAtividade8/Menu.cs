﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade8
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            frmExercicio1 frmEx1 = new frmExercicio1();
            frmEx1.MdiParent = this;
            frmEx1.WindowState = FormWindowState.Maximized;
            frmEx1.Show();
        }

        private void btnExercício2_Click(object sender, EventArgs e)
        {
            frmExercicio2 frmEx2 = new frmExercicio2();
            frmEx2.MdiParent = this;
            frmEx2.WindowState = FormWindowState.Maximized;
            frmEx2.Show();
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            frmExercicio3 frmEx3 = new frmExercicio3();
            frmEx3.MdiParent = this;
            frmEx3.WindowState = FormWindowState.Maximized;
            frmEx3.Show();

        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            frmExercicio4 frmEx4 = new frmExercicio4();
            frmEx4.MdiParent = this;
            frmEx4.WindowState = FormWindowState.Maximized;
            frmEx4.Show();
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            frmExercicio5 frmEx5 = new frmExercicio5();
            frmEx5.MdiParent = this;
            frmEx5.WindowState = FormWindowState.Maximized;
            frmEx5.Show();
        }

        private void btnExercicio6_Click(object sender, EventArgs e)
        {
            frmExercicio6 frmEx6 = new frmExercicio6();
            frmEx6.MdiParent = this;
            frmEx6.WindowState = FormWindowState.Maximized;
            frmEx6.Show();
        }
    }
}
