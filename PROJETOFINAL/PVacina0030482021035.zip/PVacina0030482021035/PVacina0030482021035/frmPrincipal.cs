﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace PVacina0030482021035
{
    public partial class frmPrincipal : Form
    {
        public static SqlConnection conexao;
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {
            //conexao de conexao da sua máquina
            try
            {
                conexao = new SqlConnection("Data Source=DESKTOP-5LEHGMA;Initial Catalog=Lp2;Integrated Security=True;Pooling=False");
                conexao.Open();
            }
            catch(SqlException ex)
            {
                MessageBox.Show("Erro de banco de dados"+ ex.Message);
            }
            catch(Exception ex)
            {
                MessageBox.Show("Outros tipos de erro"+ex.Message);
            }
            
        }

        private void vacinaçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmVacina FRMVacina = new frmVacina();
            FRMVacina.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            FRMVacina.MdiParent = this;
            FRMVacina.Show();
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSobreGrupo FRMSobre = new frmSobreGrupo();
            FRMSobre.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            FRMSobre.MdiParent = this;
            FRMSobre.Show();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
