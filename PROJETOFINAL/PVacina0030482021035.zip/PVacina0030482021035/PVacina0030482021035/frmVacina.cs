﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace PVacina0030482021035
{
    public partial class frmVacina : Form
    {
        private BindingSource bnVacina = new BindingSource();
        private bool bInclusao = false;
        private DataSet dsVacina = new DataSet();

        private DataSet dsCidade = new DataSet();

        private DataSet dsEnfermeiro = new DataSet();
    
        public frmVacina()
        {
            InitializeComponent();
        }

        private void frmVacina_Load(object sender, EventArgs e)
        {
            
            try
            {
                Vacina RegVac = new Vacina();
                dsVacina.Tables.Add(RegVac.Listar());
                bnVacina.DataSource = dsVacina.Tables["Vacina"];
                dgvVacina.DataSource = bnVacina;
                bnvVacina.BindingSource = bnVacina;

                txtIDVacina.DataBindings.Add("TEXT", bnVacina, "id_vacina");
                txtNomeVacina.DataBindings.Add("TEXT", bnVacina, "nome_vacina");
                dtNascVacina.DataBindings.Add("TEXT", bnVacina, "datanasc_vacina");
                txtEndVacina.DataBindings.Add("TEXT", bnVacina, "end_vacina");
                dtDataVacina.DataBindings.Add("TEXT", bnVacina, "data_vacina");
                mskbxCpfVacina.DataBindings.Add("TEXT", bnVacina, "cpf_vacina");
                mskbxRgVacina.DataBindings.Add("TEXT", bnVacina, "rg_vacina");
                cbxComorbidadeVacina.DataBindings.Add("SelectedItem", bnVacina, "comorbidade_vacina");
                cbxPrioritarioVacina.DataBindings.Add("SelectedItem", bnVacina, "grupopriori_vacina");
                cbxTipoVacina.DataBindings.Add("SelectedItem", bnVacina, "tipo_vacina");
               
                //cbxCidade.DataBindings.Add("SelectedItem", bnCidade, "cidade_id_cidade");
                
                // AJUSTAR DROPDOWNSTYLE PARA DropDownList PARA NAO DEIXAR INCLUIR

                Cidade cid = new Cidade();
                dsCidade.Tables.Add(cid.Listar());

                cbxCidade.DataSource = dsCidade.Tables["cidade"];

                cbxCidade.DisplayMember = "nome_cidade";

                cbxCidade.ValueMember = "id_cidade";

                cbxCidade.DataBindings.Add("SelectedValue", bnVacina, "cidade_id_cidade");

                Enfermeiro enf = new Enfermeiro();
                dsEnfermeiro.Tables.Add(enf.Listar());

                cbxEnfermeiro.DataSource = dsEnfermeiro.Tables["enfermeiro"];

                cbxEnfermeiro.DisplayMember = "nome_enfermeiro";

                cbxEnfermeiro.ValueMember = "id_enfermeiro";

                cbxEnfermeiro.DataBindings.Add("SelectedValue", bnVacina, "enfermeiro_id_enfermeiro");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            if(tbVacina.SelectedIndex == 0)
            {
                tbVacina.SelectTab(1);
            }
            bnVacina.AddNew();

            txtNomeVacina.Enabled = true;
            txtEndVacina.Enabled = true;
            dtNascVacina.Enabled = true;
            dtDataVacina.Enabled = true;
            mskbxCpfVacina.Enabled = true;
            mskbxRgVacina.Enabled = true;

            cbxCidade.Enabled = true;
            cbxEnfermeiro.Enabled = true;
            cbxComorbidadeVacina.Enabled = true;
            cbxPrioritarioVacina.Enabled = true;
            cbxTipoVacina.Enabled = true;

            cbxComorbidadeVacina.SelectedIndex = 0;
            cbxPrioritarioVacina.SelectedIndex = 0;
            cbxTipoVacina.SelectedIndex = 0;
            cbxCidade.SelectedIndex = 0;
            cbxEnfermeiro.SelectedIndex = 0;

            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovo.Enabled = false;
            btnExluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = true;
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if(tbVacina.SelectedIndex ==0)
            {
                tbVacina.SelectTab(1);
            }
        
            txtNomeVacina.Enabled = true;
            txtEndVacina.Enabled = true;
            dtNascVacina.Enabled = true;
            dtDataVacina.Enabled = true;
            mskbxCpfVacina.Enabled = true;
            mskbxRgVacina.Enabled = true;

            cbxCidade.Enabled = true;
            cbxEnfermeiro.Enabled = true;
            cbxComorbidadeVacina.Enabled = true;
            cbxPrioritarioVacina.Enabled = true;
            cbxTipoVacina.Enabled = true;

            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovo.Enabled = false;
            btnExluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = false;


        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            //validar os dados

            if (txtNomeVacina.Text == "")
                MessageBox.Show("Nome vazio");
            else
                if (txtEndVacina.Text == "")
                    MessageBox.Show("Endereço vazio");
            else
                if (mskbxCpfVacina.Text == "")
                    MessageBox.Show("CPF vazio");
            else
                if (mskbxRgVacina.Text == "")
                    MessageBox.Show("RG vazio");
            else
            {
                Vacina RegVac = new Vacina();
                RegVac.NomeVacina = txtNomeVacina.Text;
                RegVac.EndVacina = txtEndVacina.Text;
                RegVac.DataNascVacina = Convert.ToDateTime(dtNascVacina.Text);
                RegVac.DataVacina = Convert.ToDateTime(dtDataVacina.Text);
                RegVac.CpfVacina = mskbxCpfVacina.Text;
                RegVac.RgVacina = mskbxRgVacina.Text;
                RegVac.GrupoPrioriVacina = Convert.ToChar(cbxPrioritarioVacina.SelectedItem.ToString());
                RegVac.TipoVacina = Convert.ToChar(cbxTipoVacina.SelectedItem.ToString());
                RegVac.ComorbidadeVacina = Convert.ToChar(cbxComorbidadeVacina.SelectedItem.ToString());
                //RegVac.CidadeIdCidade = Convert.ToInt32(txtCidade.Text);
                RegVac.CidadeIdCidade = Convert.ToInt32(cbxCidade.SelectedValue.ToString());
                RegVac.EnfermeiroIdEnfermeiro = Convert.ToInt32(cbxEnfermeiro.SelectedValue.ToString());
            
                if(bInclusao)
                {
                    if(RegVac.Salvar()>0)
                    {
                        MessageBox.Show("Vacina adicionada com sucesso!");

                        bInclusao = false;
                        
                        txtNomeVacina.Enabled = false;
                        txtEndVacina.Enabled = false;
                        dtNascVacina.Enabled = false;
                        dtDataVacina.Enabled = false;
                        mskbxCpfVacina.Enabled = false;
                        mskbxRgVacina.Enabled = false;
  
                        cbxCidade.Enabled = false;
                        cbxEnfermeiro.Enabled = false;
                        cbxComorbidadeVacina.Enabled = false;
                        cbxPrioritarioVacina.Enabled = false;
                        cbxTipoVacina.Enabled = false;

                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovo.Enabled = true;
                        btnExluir.Enabled = true;
                        btnCancelar.Enabled = false;

                        cbxComorbidadeVacina.SelectedIndex = 0;
                        cbxPrioritarioVacina.SelectedIndex = 0;
                        cbxTipoVacina.SelectedIndex = 0;
                        cbxCidade.SelectedIndex = 0;
                        cbxEnfermeiro.SelectedIndex = 0;

                        //recarregar o grid
                        dsVacina.Tables.Clear();
                        dsVacina.Tables.Add(RegVac.Listar());
                        bnVacina.DataSource = dsVacina.Tables["vacina"];
                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar vacina");
                    }
                }
                else
                {
                    RegVac.IdVacina = Convert.ToInt32(txtIDVacina.Text);

                    if(RegVac.Alterar()>0)
                    {
                        MessageBox.Show("Vacina alterado com sucesso!");
                        txtNomeVacina.Enabled = false;
                        txtEndVacina.Enabled = false;
                        dtNascVacina.Enabled = false;
                        dtDataVacina.Enabled = false;
                        mskbxCpfVacina.Enabled = false;
                        mskbxRgVacina.Enabled = false;
                       
                        cbxEnfermeiro.Enabled = false;
                        cbxComorbidadeVacina.Enabled = false;
                        cbxPrioritarioVacina.Enabled = false;
                        cbxTipoVacina.Enabled = false;

                        cbxCidade.Enabled = false;

                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovo.Enabled = true;
                        btnExluir.Enabled = true;
                        btnCancelar.Enabled = false;

                        cbxComorbidadeVacina.SelectedIndex = 0;
                        cbxPrioritarioVacina.SelectedIndex = 0;
                        cbxTipoVacina.SelectedIndex = 0;
                        cbxCidade.SelectedIndex = 0;
                        cbxEnfermeiro.SelectedIndex = 0;

                        //recarregar o grid
                        dsVacina.Tables.Clear();
                        dsVacina.Tables.Add(RegVac.Listar());
                        bnVacina.DataSource = dsVacina.Tables["vacina"];
                    }
                    else
                    {
                        MessageBox.Show("Erro ao alterar a vacina");
                    }
                }
            }
        }

        private void btnExluir_Click(object sender, EventArgs e)
        {
            if (tbVacina.SelectedIndex == 0)
            {
                tbVacina.SelectTab(1);
            }
            Vacina RegVac = new Vacina();
            RegVac.IdVacina = Convert.ToInt32(txtIDVacina.Text);

            if (MessageBox.Show("Confirma exclusão?", "Yes or No", MessageBoxButtons.YesNo, 
                MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                if (RegVac.Excluir() == 0)
                {
                    MessageBox.Show("Erro ao excluir vacina");
                }
                else
                {
                    MessageBox.Show("Vacina excluida com sucesso");
                    dsVacina.Tables.Clear();
                    dsVacina.Tables.Add(RegVac.Listar());
                    bnVacina.DataSource = dsVacina.Tables["vacina"];
                }
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            bnVacina.CancelEdit();
            txtNomeVacina.Enabled = false;
            txtEndVacina.Enabled = false;
            dtNascVacina.Enabled = false;
            dtDataVacina.Enabled = false;
            mskbxCpfVacina.Enabled = false;
            mskbxRgVacina.Enabled = false;

            cbxCidade.Enabled = false;
            cbxEnfermeiro.Enabled = false;
            cbxComorbidadeVacina.Enabled = false;
            cbxPrioritarioVacina.Enabled = false;
            cbxTipoVacina.Enabled = false;

            btnSalvar.Enabled = false;
            btnAlterar.Enabled = true;
            btnNovo.Enabled = true;
            btnExluir.Enabled = true;
            btnCancelar.Enabled = false;


        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
