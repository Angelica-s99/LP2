﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;

namespace PVacina0030482021035
{
    class Cidade
    {
        // atributos
        private int idCidade;
        private string nomeCidade;
        private string ufCidade;

        //properties
        public int IdCidade
        {
            get
            {
                return idCidade;
            }
            set
            {
                idCidade = value;
            }
        }

        public string NomeCidade
        {
            get
            {
                return nomeCidade;
            }

            set
            {
                nomeCidade = value;
            }
        }

        public string UfCidade
        {
            get
            {
                return ufCidade;
            }
            set
            {
                ufCidade = value;
            }
        }
        public DataTable Listar()
        {
            SqlDataAdapter daCidade;

            DataTable dtdaCidade = new DataTable();

            try
            {
                daCidade = new SqlDataAdapter("SELECT * FROM CIDADE", frmPrincipal.conexao);
                daCidade.Fill(dtdaCidade);
                daCidade.FillSchema(dtdaCidade, SchemaType.Source);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtdaCidade;
        }
    }
}
