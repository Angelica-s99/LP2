﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PClasses
{
    public partial class frmMensalista : Form
    {
        public frmMensalista()
        {
            InitializeComponent();
        }


        private void btnInstanciar_Click(object sender, EventArgs e)
        {
            Mensalista mensalista = new Mensalista();
            mensalista.Matricula = Convert.ToInt32(txtMatricula.Text);
            mensalista.NomeEmpregado = txtNome.Text;
            mensalista.DataEntradaEmpresa = Convert.ToDateTime(txtData.Text);
            mensalista.SalarioMensal = Convert.ToDouble(txtSalario.Text);

            //get
            MessageBox.Show("Matricula: " + mensalista.Matricula +
                            "\nNome      : " + mensalista.NomeEmpregado +
                            "\nData Entrada: " + mensalista.DataEntradaEmpresa.ToShortDateString() +
                            "\nSalário Mensal: " + mensalista.SalarioBruto().ToString("N2")+
                            "\nTempo Empresa (em dias): " + mensalista.TempoTrabalho());
        }

        private void btnParametro_Click(object sender, EventArgs e)
        {
            Mensalista mensalista = new Mensalista(Convert.ToInt32(txtMatricula.Text), txtNome.Text,
                Convert.ToDateTime(txtData.Text), Convert.ToDouble(txtSalario.Text));

            MessageBox.Show("Matricula: " + mensalista.Matricula +
                            "\nNome      : " + mensalista.NomeEmpregado +
                            "\nData Entrada: " + mensalista.DataEntradaEmpresa.ToShortDateString() +
                            "\nSalário Mensal: " + mensalista.SalarioBruto().ToString("N2") +
                                "\nTempo Empresa (em dias): " + mensalista.TempoTrabalho());
        
        }
    }
}
