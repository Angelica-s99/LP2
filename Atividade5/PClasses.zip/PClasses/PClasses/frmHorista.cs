﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PClasses
{
    public partial class frmHorista : Form
    {
        public frmHorista()
        {
            InitializeComponent();
        }


        private void btnInstanciar_Click(object sender, EventArgs e)
        {
            Horista objHorista = new Horista();
            objHorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objHorista.NomeEmpregado = txtNome.Text;
            objHorista.NumeroHora = Convert.ToInt32(txtNumeroHoras.Text);
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txtData.Text);
            objHorista.SalarioHora = Convert.ToInt32(txtSalarioHora.Text);
            objHorista.DiasFalta = Convert.ToInt32(txtDiaFalta.Text);

            MessageBox.Show("Matrícula: " + objHorista.Matricula +
                            "\nNome do Empregado: " + objHorista.NomeEmpregado +
                            "\nTempo de Trabalho: " + objHorista.TempoTrabalho().ToString() +
                            "\nDias Faltas: " + objHorista.DiasFalta +
                            "\nSalário Bruto: " + objHorista.SalarioBruto().ToString("N2"));
        }

        private void btnParametro_Click(object sender, EventArgs e)
        {
            Horista objHorista = new Horista(Convert.ToInt32(txtMatricula.Text), txtNome.Text,
            Convert.ToInt32(txtDiaFalta.Text), Convert.ToInt32(txtNumeroHoras.Text),
            Convert.ToDouble(txtSalarioHora.Text), Convert.ToDateTime(txtData.Text));

            MessageBox.Show("Matrícula: " + objHorista.Matricula +
                            "\nNome do Empregado: " + objHorista.NomeEmpregado +
                            "\nTempo de Trabalho: " + objHorista.TempoTrabalho().ToString() +
                            "\nDias Faltas: " + objHorista.DiasFalta +
                            "\nSalário Bruto: " + objHorista.SalarioBruto().ToString("N2"));
        }
    }
}
