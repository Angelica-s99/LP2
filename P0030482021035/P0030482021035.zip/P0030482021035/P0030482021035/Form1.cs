﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P0030482021035
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVendas_Click(object sender, EventArgs e)
        {
       
            double auxiliar = 0, totalGeral = 0, semana = 0;
            double[,] venda = new double[5, 4];

            for (int j = 0; j < 5; j++)
            {
                for (int i = 0; i < 4; i++)
                {
                    auxiliar = Convert.ToDouble(Interaction.InputBox("Digite a venda da semana" + (i + 1), "Digite a venda do mês" + (j + 1)));

                    venda[j, i] = auxiliar;

                }
            }
                
                for (int mes = 0; mes < 5; mes++)
                {
                    for (int sem = 0; sem < 4; sem++)
                    {
                        semana = semana + venda[mes, sem];
                        lstbxVendas.Items.Add("Total de mês: " + (mes + 1) + " Semana: " + (sem + 1) + " " + venda[mes, sem].ToString("C"));
                    }
                    totalGeral = totalGeral + semana;
                    lstbxVendas.Items.Add("Total do mês :" + semana);
                    semana = 0;

                }
                lstbxVendas.Items.Add("Total Geral: " + totalGeral.ToString("C"));

            
            

        }
    }
}
