﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSalario
{
    public partial class Form1 : Form
    {
        double salarioBruto;
        public Form1()
        {
            InitializeComponent();
            
        }
       
        private void btnVerificar_Click(object sender, EventArgs e)
        {
            
            if ((txtNomeFuncionario.Text == "") || txtNomeFuncionario.Text.Length < 5)
            {
                MessageBox.Show("Valor inválido");
            }
            else if (!double.TryParse(mskbxSalarioBruto.Text, out salarioBruto))
            {
                MessageBox.Show("Valor não informado");
            }
            else
            {
                lblMensagem.Visible = true;

                double descontoInss = 0;
                double descontoIr = 0;
                double salarioFamilia = 0;
                int quantidadeFilhos = 0;


                if (salarioBruto <= 800.47)
                {
                    txtAliquotaInss.Text = "7.65%";
                    descontoInss = 7.65 / 100 * salarioBruto;
                    txtDescontoINSS.Text = descontoInss.ToString("N2");
                    //mskbxDescontoInss.Text = descontoInss.ToString("N2");

                }
                else if (salarioBruto <=1050)
                {
                    txtAliquotaInss.Text = "8.65%";
                    descontoInss = 8.65 / 100 * salarioBruto;
                    txtDescontoINSS.Text = descontoInss.ToString("N2");
                    //mskbxDescontoInss.Text = descontoInss.ToString("N2");
                }
                else if(salarioBruto <= 1400.77)
                {
                    txtAliquotaInss.Text = "9,00%";
                    descontoInss = 9 / 100 * salarioBruto;
                    txtDescontoINSS.Text = descontoInss.ToString("N2");
                    //mskbxDescontoInss.Text = descontoInss.ToString("N2");
                }
                else if(salarioBruto <= 2801.56)
                {
                    txtAliquotaInss.Text = "11,00%";
                    descontoInss = 11 / 100 * salarioBruto;
                    txtDescontoINSS.Text = descontoInss.ToString("N2");
                    //mskbxDescontoInss.Text = descontoInss.ToString("N2");
                }
                else 
                {
                    txtAliquotaInss.Text = "R$ 308,17";
                    descontoInss =  308.17;
                    txtDescontoINSS.Text = descontoInss.ToString("N2");
                    //mskbxDescontoInss.Text= descontoInss.ToString("N2");
                }
                
                
                if(salarioBruto <= 1257.12)
                {
                    
                    descontoIr = salarioBruto * 0;
                    txtAliquotaIr.Text = "0.00";
                    txtDescontoIr.Text = descontoIr.ToString("N2");
                    //msktbxDescontoIr.Text = descontoIr.ToString("N2");
                }
                else if(salarioBruto <= 2512.08)
                {
                    txtAliquotaIr.Text = "15,00%";
                    descontoIr = salarioBruto * (15 / 100);
                    txtDescontoIr.Text = descontoIr.ToString("N2");
                    //msktbxDescontoIr.Text = descontoIr.ToString("N2");

                }
                else
                {
                    txtAliquotaIr.Text = "27.5%";
                    descontoIr = salarioBruto * (25.5 / 100);
                    txtDescontoIr.Text = descontoIr.ToString("N2");
                    //msktbxDescontoIr.Text = descontoIr.ToString("N2");
                }

                if (salarioBruto <= 435.52)
                {
                     quantidadeFilhos = Convert.ToInt32(cbxQuantidadeFilhos.SelectedItem);
                     salarioFamilia = 22.33 * quantidadeFilhos;
                    txtSalarioFamilia.Text = salarioFamilia.ToString("N2");
                    //mskbxSalarioFamilia.Text = salarioFamilia.ToString("N2");
                }
                else if (salarioBruto <=654.61)
                {
                    quantidadeFilhos = Convert.ToInt32(cbxQuantidadeFilhos.SelectedItem);
                    salarioFamilia = 15.74 * quantidadeFilhos;
                    txtSalarioFamilia.Text = salarioFamilia.ToString("N2");
                    //mskbxSalarioFamilia.Text = salarioFamilia.ToString("N2");
                }
                else
                {
                    salarioFamilia = 0;
                    txtSalarioFamilia.Text = salarioFamilia.ToString();
                    //mskbxSalarioFamilia.Text = salarioFamilia.ToString("N2");
                }
                double salarioLiquido = 0;
                salarioLiquido = salarioBruto - descontoInss - descontoIr + salarioFamilia;
                txtSalarioLiquido.Text= " R$ "+ string.Format("{0:C}",salarioLiquido.ToString("N2"));
                txtSalarioLiquido.Text = salarioLiquido.ToString("N2");

                string texto = "Os descontos do salário";
                if (rbtnFeminino.Checked)
                {
                    texto = texto + " da sra. " + txtNomeFuncionario.Text;
                }
                else
                {
                    texto = texto + " do sr. " + txtNomeFuncionario.Text;
                }
                if (ckbxCasado.Checked)
                {
                    texto = texto + " que é casado(a) ";
                }
                else
                {
                    texto = texto + " que é solteiro(a) ";
                }

                texto = texto + " e que tem " + cbxQuantidadeFilhos.SelectedItem.ToString() +
                    " filho(s) são: ";

                lblMensagem.Text = texto;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtNomeFuncionario.Focus();
        }
    }
}
