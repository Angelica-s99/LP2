﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double altura;
            double peso;
            double pesoIdeal;


            if (!double.TryParse(mskbxAltura.Text, out altura) || !double.TryParse(mskbxPeso.Text, out peso))
            {
                MessageBox.Show("Não foi inserido valores");
            }
            else
            {
                altura = Convert.ToDouble(mskbxAltura.Text);
                peso = Convert.ToDouble(mskbxPeso.Text);

                if (rbtnFeminino.Checked)
                {
                    pesoIdeal = Math.Round(((62.1*altura)-44.7));
                    if (pesoIdeal == peso)
                    {
                        MessageBox.Show("Você está com o peso ideal!!");
                    }
                    else if (peso > pesoIdeal)
                    {
                        MessageBox.Show("Regime obrigatório já!!!");
                    }
                    else
                    {
                        MessageBox.Show("Coma bastante doce!!!");
                    }

                }
                else
                {
                    pesoIdeal = Math.Round(((72.7 * altura) - 58));

                    if (pesoIdeal == peso)
                    {
                        MessageBox.Show("Você está com o peso ideal!!");
                    }
                    else if (peso > pesoIdeal)
                    {
                        MessageBox.Show("Regime obrigatório já!!!");
                    }
                    else
                    {
                        MessageBox.Show("Coma bastante doce!!!");
                    }

                }


            }
        }
    }
}
